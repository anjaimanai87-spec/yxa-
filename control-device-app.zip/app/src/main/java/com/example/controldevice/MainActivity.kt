package com.example.controldevice

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var server: EditText
    private lateinit var adminToken: EditText
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        output = TextView(this).apply {
            text = "Belum terhubung ke backend."
            textSize = 17f
        }
        server = EditText(this).apply {
            hint = "Backend URL HTTPS"
        }
        adminToken = EditText(this).apply {
            hint = "Admin access token"
        }
        val list = Button(this).apply { text = "Muat perangkat" }
        val pair = Button(this).apply { text = "Buat kode pairing" }

        list.setOnClickListener { getDevices() }
        pair.setOnClickListener { createPairCode() }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            addView(TextView(this@MainActivity).apply {
                text = "DEVICE CONTROL"
                textSize = 25f
            })
            addView(server)
            addView(adminToken)
            addView(pair)
            addView(list)
            addView(output)
        })
    }

    private fun base(): String = server.text.toString().trimEnd('/')
    private fun request(path: String, method: String = "GET", body: RequestBody? = null): Request {
        return Request.Builder()
            .url(base() + path)
            .header("Authorization", "Bearer ${adminToken.text}")
            .method(method, body)
            .build()
    }

    private fun createPairCode() {
        if (base().isBlank() || adminToken.text.isBlank()) {
            output.text = "URL server dan token admin wajib diisi."
            return
        }
        val body = JSONObject().apply { put("purpose", "device_pairing") }
            .toString().toRequestBody("application/json".toMediaType())
        client.newCall(request("/api/v1/pairing/codes", "POST", body))
            .enqueue(callback("Kode pairing"))
    }

    private fun getDevices() {
        if (base().isBlank() || adminToken.text.isBlank()) {
            output.text = "URL server dan token admin wajib diisi."
            return
        }
        client.newCall(request("/api/v1/devices"))
            .enqueue(callback("Daftar perangkat"))
    }

    private fun callback(label: String) = object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            runOnUiThread { output.text = "$label gagal: ${e.message}" }
        }
        override fun onResponse(call: Call, response: Response) {
            response.use {
                val body = response.body?.string().orEmpty()
                runOnUiThread {
                    output.text = "$label — HTTP ${response.code}\n\n$body"
                }
            }
        }
    }
}
