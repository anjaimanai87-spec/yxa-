# Control Device APK

Aplikasi kontrol/admin untuk perangkat yang telah dipair secara sah.

## Fitur
- Backend HTTPS configurable.
- Bearer token admin.
- Membuat kode pairing.
- Mengambil daftar perangkat.
- Menampilkan respons/status dari server.

## Endpoint backend
POST /api/v1/pairing/codes
Authorization: Bearer <admin-token>

GET /api/v1/devices
Authorization: Bearer <admin-token>

POST /api/v1/devices/pair
Dipanggil APK Target dengan:
{"device_id":"...","pair_code":"..."}

POST /api/v1/devices/heartbeat
Dipanggil APK Target dengan:
{"device_id":"..."}

Untuk produksi, backend wajib menerapkan autentikasi kuat, TLS, expiry pairing code, token per perangkat, rate limiting, audit log, dan kontrol akses berbasis peran.

Build:
./gradlew assembleDebug
